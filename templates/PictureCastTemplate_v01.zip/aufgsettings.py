#!/usr/bin/python3.3

IMG = "f.300x300.png"

RCV_PORT = 7073
RCV_ADDR = "127.0.0.1"
RCV_BIND_ADDR = ""
MAX_PAYLOAD_SIZE = 1000

print("# ")
print("# = Vorlesung Internetkommunikation")
print("# = UDP Programmieraufgabe")
print("#")
print("# = Current settings =")
print("# Image: " + IMG)
print("# Receiver Port: " + str(RCV_PORT))
print("# Receiver Address: " + str(RCV_ADDR))
print("# Receiver Bind Address: " + str(RCV_BIND_ADDR))
print("# Max payload bytes per packet: " + str(MAX_PAYLOAD_SIZE))
