Zugangsdaten Mailserver:

IP: 129.187.223.142
Port: 110 (POP3)

Benutzername/Kennwort: user/user 

Alternativ: Matrikelnummer/password (wird angekündigt sobald verfügbar, voraussichtlich ab dem 22.4.)

Hinweis: In der Mailbox sind 2 Beispielmails vorhanden. Werden diese gelöscht stellt der Server sie automatisch spätestens nach einer Minute wieder her.